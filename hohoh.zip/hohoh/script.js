const introScene   = document.getElementById('intro-scene');
const siteContent  = document.getElementById('site-content');
const flashOverlay = document.getElementById('flash-overlay');

introScene.addEventListener('click', () => {
  if (introScene.classList.contains('zooming')) return;

  // 1. Inicia o zoom (CSS cuida da animação de 1.2s)
  introScene.classList.add('zooming');

  // 2. Depois de 1s mostra o flash branco
  setTimeout(() => flashOverlay.classList.add('flash'), 1000);

  // 3. Depois de 1.4s esconde a intro e mostra o site
  setTimeout(() => {
    introScene.style.display = 'none';
    siteContent.style.display = 'block';
    flashOverlay.classList.remove('flash');
    setTimeout(() => siteContent.classList.add('visible'), 50);
  }, 1400);
});

// Scroll reveal: revela os cards conforme o usuário rola a página
const reveals  = document.querySelectorAll('.reveal');
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => entry.target.classList.add('revealed'), i * 100);
    }
  });
}, { threshold: 0.15 });

reveals.forEach(el => observer.observe(el));
